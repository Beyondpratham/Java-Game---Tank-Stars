package com.badlogic.tankgame;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Rectangle;

public class shoot {
    Texture fire;
    Rectangle Fire;
    private static int n;
    public shoot(int n){
        this.n=n;
    }
//    public fire(){
//        return none;
//    }
}
